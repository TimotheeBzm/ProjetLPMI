<?php
include('confirmation_ajout_m.php');
include('confirmation_ajout_v.php');
?>