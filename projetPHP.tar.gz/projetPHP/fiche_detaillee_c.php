<?php
include('fiche_detaillee_m.php');
include('fiche_detaillee_v.php');
?>