<?php
echo "Produit ajouté";
echo "<br>";
echo "<br>";
echo "<a href='ajout_produit_c.php'>Ajouter un nouveau produit</a>";
echo "<br>";
echo "<a href='liste_produits_c.php'>Retour</a>";
?>