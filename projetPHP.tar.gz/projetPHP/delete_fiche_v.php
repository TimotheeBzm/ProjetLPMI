<?php
echo "le produit ".$id_prod." a été supprimé";
echo "<br>";
echo "<a href='liste_produits_c.php'>Retour</a>";
?>