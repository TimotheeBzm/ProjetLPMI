<?php
include('ajout_produit_m.php');
include('ajout_produit_v.php');
?>