<?php
include('delete_fiche_m.php');
include('delete_fiche_v.php');

?>