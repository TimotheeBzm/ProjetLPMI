<?php
include('confirmation_update_produit_m.php');
include('confirmation_update_produit_v.php');
?>