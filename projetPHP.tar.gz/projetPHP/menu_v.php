<div id="menus">
    <div class='menu'><a href="liste_produits_c.php">Tous les produits</a></div>
    <div class='menu'><a href="liste_produits_c.php?categ=dvd">DVD</a></div>
    <div class='menu'><a href="liste_produits_c.php?categ=br">Bluray</a></div>
    <div class='menu'><a href="moteur_c.php">Recherche</a></div>
    <div class='menu'><a href="ajout_produit_c.php">Ajout produits</a></div>
</div>