<?php
include('liste_produits_m.php');
include('liste_produits_v.php');

?>