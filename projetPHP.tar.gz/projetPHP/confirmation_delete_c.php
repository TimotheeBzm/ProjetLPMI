<?php
include('confirmation_delete_m.php');
include('confirmation_delete_v.php');

?>